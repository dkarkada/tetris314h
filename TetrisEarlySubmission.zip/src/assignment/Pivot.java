package assignment;

public class Pivot {
	double x;
	double y;
	public Pivot(double xcoord, double ycoord) {
		x = xcoord;
		y = ycoord;
	}
	public double getX() {return x;}
	public double getY() {return y;}
}
